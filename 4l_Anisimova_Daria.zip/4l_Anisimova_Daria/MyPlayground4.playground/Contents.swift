import Cocoa

var str = "Hello, playground"

enum CarBrand {
    case BMW, Porshe, Mercedes, Scania, Volvo
}

enum CarMotorState {
    case on, off
}

enum CarWindowState {
    case open, close
}

enum CarFuel {
    case petrol, diesel
}

enum CarTonnage: String {
    case small = "малая"
    case middle = "средняя"
    case big = "большая"
}

class Car {
    let brand: CarBrand
    let year: Int
    var km: Double
    var motorState: CarMotorState
    var windowState: CarWindowState

    init(brand: CarBrand, year: Int, km: Double, motorState: CarMotorState, windowState: CarWindowState) {
        self.brand = brand
        self.year = year
        self.km = km
        self.motorState = motorState
        self.windowState = windowState
    }

    func openWindows() {
        windowState = .open
    }

    func closeWindows() {
        windowState = .close
    }
    
    func startTheEngine() {
        motorState = .on
        }

    func shutDownTheEngine () {
        motorState = .off
        }
}

var car1 = Car(brand: .Mercedes, year: 2018, km: 55, motorState: .off, windowState: .close)
var car2 = Car(brand: .Porshe, year: 2020, km: 0.0, motorState: .on, windowState: .open)


class SportCar: Car {
    var freeTrunk: Double
    
    init(brand: CarBrand, year: Int, km: Double, motorState: CarMotorState, windowState: CarWindowState, freeTrunk: Double) {
        self.freeTrunk = freeTrunk
        super.init(brand: brand, year: year, km: km, motorState: motorState, windowState: windowState)
    }

        override func openWindows() {
        print ("В спортивном режиме окна нельзя открыть")
        }
        override func closeWindows() {
        super.closeWindows()
        print("Окна закрыты")
        }
}

var sportCar1 = SportCar(brand: .BMW, year: 2020, km: 25, motorState: .off, windowState: .close, freeTrunk: 35)
var sportCar2 = SportCar(brand: .Porshe, year: 2019, km: 0.0, motorState: .on, windowState: .open, freeTrunk: 55)

print(sportCar1.windowState)
sportCar1.openWindows()
print(sportCar1.windowState)

func printSportCarProperties (sportCar: SportCar) {
    print("------------------------------------------------------------------------")
    print("Бренд: \(sportCar.brand)")
    print("Год выпуска: \( sportCar.year)")
    print("Пробег: \(sportCar.km)")
    print("Мотор: \( sportCar.motorState == .on ? "Включен" : "Выключен")")
    print("Окна: \( sportCar.windowState == .open ? "Открыты" : "Закрыты")")
    print("Объем багажника: \( sportCar.freeTrunk)")
    }

printSportCarProperties(sportCar: sportCar1)
printSportCarProperties(sportCar: sportCar2)

class TrunkCar: Car {
    var fuel: CarFuel
    var tonnage: CarTonnage
    init(brand: CarBrand, year: Int, km: Double, motorState: CarMotorState, windowState: CarWindowState, fuel: CarFuel, tonnage: CarTonnage) {
        self.fuel = fuel
        self.tonnage = tonnage
        super.init(brand: brand, year: year, km: km, motorState: motorState, windowState: windowState)
    }

    override func startTheEngine() {
        print ("Наблюдается усталость водителя. Вы не можете запустить мотор")
    }

    override func shutDownTheEngine () {
        super.shutDownTheEngine ()
        print("Мотор выключен")
    }
}

var trunk1 = TrunkCar(brand: .Volvo, year: 2020, km: 1000, motorState: .off, windowState: .close, fuel: .diesel, tonnage: .big)
var trunk2 = TrunkCar(brand: .Scania, year: 2019, km: 2500, motorState: .off, windowState: .close, fuel: .petrol, tonnage: .middle)

print(trunk2.motorState)
trunk2.startTheEngine()
print(trunk2.motorState)

func printTrunkCarProperties (trunkCar: TrunkCar) {
    print("------------------------------------------------------------------------")
    print("Бренд: \(trunkCar.brand)")
    print("Год выпуска: \(trunkCar.year)")
    print("Пробег: \(trunkCar.km)")
    print("Мотор: \(trunkCar.motorState == .on ? "Включен" : "Выключен")")
    print("Окна: \(trunkCar.windowState == .open ? "Открыты" : "Закрыты")")
    print("Топливо: \(trunkCar.fuel == .petrol ? "Бензин" : "Дизель")")
    print("Грузоподъемность: \(trunkCar.tonnage.rawValue)")

}

printTrunkCarProperties(trunkCar: trunk1)
