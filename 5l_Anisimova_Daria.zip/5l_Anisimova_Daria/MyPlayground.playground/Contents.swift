import Cocoa

var str = "Hello, playground"

enum CarMotorState: String {
    case on = "включен"
    case off = "выключен"
}

enum CarWindowState: String {
    case open = "открыты"
    case close = "закрыты"
}

enum CarTonnage: String {
    case small = "малая"
    case middle = "средняя"
    case big = "большая"
}

protocol CarProtocol {
    var brand: String {get}
    var year: Int {get}
    var km: Double {get set}
    var windowState: CarWindowState {get set}
    var motorState: CarMotorState {get set}
}


extension CarProtocol {
    
    mutating func changeTheWindowState() {
        switch windowState {
        case .open:
            windowState = CarWindowState.close
            print("Окна:\(windowState.rawValue)")
        case .close:
            windowState = CarWindowState.open
            print("Окна:\(windowState.rawValue)")
        }
}
    mutating func changeTheMotorState (to: CarMotorState) {
        motorState = to
}
}

class SportCar: CarProtocol {
    
    var brand: String
    let year: Int
    var km: Double
    var windowState: CarWindowState
    var motorState: CarMotorState
    var sportMode: Bool
    var trunk: Double
    let maxSpeed: Double

    init(brand: String, year: Int, km: Double, windowstate: CarWindowState, motorState: CarMotorState, sportMode: Bool, trunk: Double, maxSpeed: Double) {
        self.brand = brand
        self.year = year
        self.km = km
        self.windowState = windowstate
        self.motorState = motorState
        self.sportMode = sportMode
        self.trunk = trunk
        self.maxSpeed = maxSpeed
}
}

var sportCar1 = SportCar(brand: "BMW", year: 2020, km: 0.0, windowstate: .close, motorState: .off, sportMode: true, trunk: 25.0, maxSpeed: 350.0)
var sportCar2 = SportCar(brand: "Porsche", year: 2020, km: 120.0, windowstate: .open, motorState: .on, sportMode: false, trunk: 35.0, maxSpeed: 250.0)


sportCar1.changeTheMotorState(to: .on)
print(sportCar1.motorState.rawValue)

sportCar1.changeTheWindowState()
print(sportCar1.windowState.rawValue)

class TrunkCar: CarProtocol {
    
    var brand: String
    let year: Int
    var km: Double
    var windowState: CarWindowState
    var motorState: CarMotorState
    var navigate: Bool
    var tonnage: CarTonnage
    let maxWeight: Double
    
    init(brand: String, year: Int, km: Double, windowstate: CarWindowState, motorState: CarMotorState, navigate: Bool, tonnage: CarTonnage, maxWeight: Double){
        self.brand = brand
        self.year = year
        self.km = km
        self.windowState = windowstate
        self.motorState = motorState
        self.navigate = navigate
        self.tonnage = tonnage
        self.maxWeight = maxWeight
}
}

var trunkCar1 = TrunkCar(brand: "Scania", year: 2018, km: 27000.0, windowstate: .close, motorState: .off, navigate: true, tonnage: .big, maxWeight: 5000.0)
var trunkCar2 = TrunkCar(brand: "Volvo", year: 2017, km: 155000.0, windowstate: .open, motorState: .on, navigate: false, tonnage: .middle, maxWeight: 7000.0)

extension TrunkCar: CustomStringConvertible {
    var description: String {
        return """
            Бренд: \(brand)
            Год выпуска: \(year)
            Пробег: \(km)
            Состояние окон: \(windowState.rawValue)
            Состояние мотора: \(motorState.rawValue)
            Навигация: \(navigate ? "имеется" : "отсутсвует")
            Грузоподъемность: \(tonnage.rawValue)
            Максимальный груз: \(maxWeight)
    """
    }
}

extension SportCar: CustomStringConvertible {
    var description: String {
        return """
            Бренд: \(brand)
            Год выпуска: \(year)
            Пробег: \(km)
            Состояние окон: \(windowState.rawValue)
            Состояние мотора: \(motorState.rawValue)
            Спортивный режим: \(sportMode ? "имеется" : "отсутсвует")
            Объем багажника: \(trunk)
            Максимальная скорость: \(maxSpeed)
    """
    }
}

print(trunkCar1)

print(sportCar1)
