//
//  main.swift
//  5l_Anisimova_Daria
//
//  Created by user179829 on 10/6/20.
//

import Foundation

print("Hello, World!")

