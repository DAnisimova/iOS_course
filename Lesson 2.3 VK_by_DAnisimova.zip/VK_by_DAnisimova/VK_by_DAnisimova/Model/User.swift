//
//  User.swift
//  VK_by_DAnisimova
//
//  Created by User on 15/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import Foundation

struct User {
    
    let name: String
    let age: Int
    let city: String
    let job: String
}
