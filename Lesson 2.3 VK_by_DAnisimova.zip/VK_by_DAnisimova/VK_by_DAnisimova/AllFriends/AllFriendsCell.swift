//
//  AllFriendsCell.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsCell: UITableViewCell {

    @IBOutlet weak var friendName: UILabel!
    @IBOutlet weak var friendImage: UIImageView!
    
    func setData(name:String, image: UIImage){
        friendName.text = name
        friendImage.image = image
    }

}
