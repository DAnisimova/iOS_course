//
//  NetworkManager.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 15.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire

// Для листа с друзьями
struct FriendsListResponse: Codable {
    let response: FriendResponse
}

struct FriendResponse: Codable {
    let count: Int
    let items: [User]
}

struct User: Codable {
    let first_name: String
    let id: Int
    let last_name: String
//    let photo_50: String?
}

// Для альбома с фото
struct PhotoAlbumResponse: Codable {
    let response: PhotoResponse
}

struct PhotoResponse: Codable {
    let count: Int
    let items: [Photos]
}

struct Photos: Codable {
    let album_id: Int
    let date: Int
//    let has_tags: String
    let id: Int
    let owner_id: Int
//    let photo_1280: String
//    let photo_130: String
//    let photo_604: String
//    let photo_75: String
//    let photo_807: String
    let post_id: Int
    let text: String
}

// Для группы
struct AllGroupsResponse: Codable {
    let response: GroupResponse
}

struct GroupResponse: Codable {
    let count: Int
    let items: [Groups]
}

struct Groups: Codable {
    let id: Int
//    let is_admin: Int
//    let is_advertiser: Int
//    let is_closed: Int
//    let is_member: Int
    let name: String
//    let photo_100: String
//    let photo_200: String
//    let photo_50: String
//    let screen_name: String
    let type: String
}

class NetworkManager {
    
    static var networkManager = NetworkManager()
    
    private init() {}
    
    let baseUrl = "https://api.vk.com/method/"
    
    func getMyFriendsList() {
        let path = "/friends.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "v": 5.52,
            "fields": "photo_50"
        ]
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            
            do {
                let friend = try! JSONDecoder().decode(FriendsListResponse.self, from: response.value!)
                print(friend)
            } catch {
                print(error)
            }
    
        }
    }
    
    func getPhotosOfSelectedFriend() {
        let path = "/photos.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "owner_id": 66265,
            "album_id": "profile",
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            
            do {
                let photo = try! JSONDecoder().decode(PhotoAlbumResponse.self, from: response.value!)
                print(photo)
            } catch {
                print(error)
            }

        }
    }
    
    func getMyGroups() {
        let path = "/groups.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "extended": 1,
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            
            do {
                let group = try! JSONDecoder().decode(AllGroupsResponse.self, from: response.value!)
                print(group)
            } catch {
                print(error)
            }
           
        }
    }
    
    func getMyGroupsWithSearch() {
        let path = "/groups.search"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "q": "All about Swift",
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            
            do {
                let groupWithSearch = try! JSONDecoder().decode(AllGroupsResponse.self, from: response.value!)
                print(groupWithSearch)
            } catch {
                print(error)
            }
            
        }
    }
}


