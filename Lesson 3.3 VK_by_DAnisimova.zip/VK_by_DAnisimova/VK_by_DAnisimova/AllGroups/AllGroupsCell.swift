//
//  AllGroupsCell.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllGroupsCell: UITableViewCell {

    @IBOutlet weak var groupName: UILabel!
    @IBOutlet weak var groupImage: UIImageView!
    
}



