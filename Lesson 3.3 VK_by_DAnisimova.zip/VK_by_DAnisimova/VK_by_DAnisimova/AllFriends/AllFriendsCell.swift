//
//  AllFriendsCell.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsCell: UITableViewCell {

    @IBOutlet weak var friendName: UILabel!
    @IBOutlet weak var uiView: UIView!
    @IBOutlet weak var friendImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let tap = UITapGestureRecognizer()
        tap.addTarget(self, action: #selector(tapOnAvatar(_:)))
        friendImage.addGestureRecognizer(tap)
        friendImage.isUserInteractionEnabled = true
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    @objc func tapOnAvatar(_ tapGestureRecognizer: UITapGestureRecognizer) {
        UIView.animate(
            withDuration: 0.3,
            delay: 0,
            usingSpringWithDamping: 0.3,
            initialSpringVelocity: 1,
            options: [.autoreverse],
            animations: {
                let scale = CGAffineTransform(scaleX: 0.8, y: 0.8)
                self.friendImage.transform = scale
                self.uiView.transform = scale
        }) { _ in
            self.friendImage.transform = .identity
            self.uiView.transform = .identity
        }
    }
    
}

final class ImageView: UIImageView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        layer.cornerRadius = bounds.height / 2
        clipsToBounds = true
    }
}

final class ShadowView: UIView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        layer.shadowColor = UIColor.systemBlue.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowRadius = 5
        layer.cornerRadius = bounds.height / 2
        clipsToBounds = false
    }
}


