//
//  main.swift
//  1l_Anisimova_Daria
//
//  Created by user179829 on 9/23/20.
//

import Foundation

print("Hello, World!")

let sideA: Double = 7
let sideB: Double = 9

let sideC: Double = sqrt(sideA*sideA + sideB*sideB)
print(sideC)

let perimetr = sideA + sideB + sideC
print(perimetr)

let square = sideA*sideB/2
print(square)

let A: Double = 5
let B: Double = 6
let C: Double = 1
let D: Double = B*B - 4*A*C

let X1: Double = (-B + sqrt(D))/2*A
let X2: Double = (-B - sqrt(D))/2*A

func squareRoot(_ D: Double) -> Double?{
    if D < 0 {
        return nil
}
    return sqrt(D)
}

//let X1: Double = (-B + sqrt(D))/2*A
//let X2: Double = (-B - sqrt(D))/2*A

print(X1,X2)
