//
//  LikeButton.swift
//  VK_by_DAnisimova
//
//  Created by User on 18/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class LikeButton: UIControl {
    
    enum LikeState {
        case like
        case liked
    }
    
    let likedColor = UIColor.red
    let likeColor = UIColor.green
    
    
    let likeImageView = UIImageView(image: UIImage(named: "Liked"))
    
    var likeState = LikeState.like {
        didSet {
            self.updateLikeState(self.likeState)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.likeImageView)
        self.likeImageView.translatesAutoresizingMaskIntoConstraints = false
        let constraintY = self.likeImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        let constraintX = self.likeImageView.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        constraintX.isActive = true
        constraintY.isActive = true
        
        let width = self.likeImageView.widthAnchor.constraint(equalTo: self.widthAnchor)
        let height = self.likeImageView.heightAnchor.constraint(equalTo: self.heightAnchor)
        width.isActive = true
        height.isActive = true
        
        self.updateLikeState(self.likeState)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateLikeState(_ state: LikeState) {
        switch state {
        case .like:
            likeImageView.tintColor = self.likeColor
        case .liked:
            likeImageView.tintColor = self.likedColor
        }
    }
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        return self
    }
    
    
    
}
