//
//  AllFriendsCell.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsCell: UITableViewCell {

    @IBOutlet weak var friendName: UILabel!
    
    @IBOutlet weak var uiView: UIView! {didSet {self.uiView.clipsToBounds = false
        self.uiView.layer.shadowColor = UIColor.gray.cgColor
        self.uiView.layer.cornerRadius = self.uiView.frame.width / 2
        self.uiView.layer.shadowOpacity = 0.5
        self.uiView.layer.shadowOffset = CGSize.zero
        self.uiView.layer.shadowRadius = 5
        self.uiView.layer.shadowPath = UIBezierPath(roundedRect: self.uiView.bounds, cornerRadius: 5).cgPath
        }
    }
    
    
    @IBOutlet weak var friendImage: UIImageView! {didSet {
        
        self.friendImage.clipsToBounds = true
        self.friendImage.layer.cornerRadius = self.friendImage.frame.width/2
        }
        
    }
}

