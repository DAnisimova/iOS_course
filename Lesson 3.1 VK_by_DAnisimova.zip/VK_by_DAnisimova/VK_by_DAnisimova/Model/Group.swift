//
//  Group.swift
//  VK_by_DAnisimova
//
//  Created by User on 15/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import Foundation
import UIKit

struct Group: Equatable {
    let name: String
    let logo: UIImage
    
    static func ==(lhs: Group, rhs: Group) -> Bool {
        return lhs.name == rhs.name && lhs.logo == rhs.logo
    }
}
