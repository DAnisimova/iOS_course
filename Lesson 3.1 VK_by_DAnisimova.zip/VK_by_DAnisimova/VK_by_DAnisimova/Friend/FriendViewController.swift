//
//  FriendViewController.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class FriendViewController: UICollectionViewController {
    
    var images = [UIImage]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.delegate = self
    }


    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BigFriendCell", for: indexPath) as! FriendCell
        cell.friendImage.image = images[indexPath.item]
        
        return cell
    }
    
    // Отображение большого фото при нажатии на ячейку с этим фото
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "bigPhoto" { // проверка на нужный переход
            let cell: FriendCell = sender as! FriendCell
            let image = cell.friendImage.image
            let fullSizePhotosController: FullSizePhotosController = segue.destination as! FullSizePhotosController
            
            fullSizePhotosController.bigPhoto = image // передаем фото в экран с большим фото
           }
      }
}

extension FriendViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let cellWidth = (collectionView.bounds.width - 41) / 3
        
        return CGSize(width: cellWidth, height: cellWidth)
    }
}
