//
//  FriendCell.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class FriendCell: UICollectionViewCell {
    
    @IBOutlet weak var friendImage: UIImageView!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var numberOfLikes: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        likeButton.setImage(UIImage(named: "Liked"), for: .selected)
        likeButton.setImage(UIImage(named: "Like"), for: .normal)
    }
    
    
    @IBAction func like(_ sender: Any) {
        likeButton.isSelected.toggle()
        numberOfLikes.textColor = likeButton.isSelected ? .red : .black
        numberOfLikes.text = likeButton.isSelected ? "1" : "0"
        animateLikeButton() // добавили анимацию в момент нажатия
    }
    
    func animateLikeButton () { // создали анимацию для кнопки
        let animation = CASpringAnimation(keyPath: "transform.scale")
        animation.fromValue = 0
        animation.toValue = 1
        animation.stiffness = 200
        animation.mass = 2
        animation.duration = 2
        animation.beginTime = CACurrentMediaTime()
        animation.fillMode = CAMediaTimingFillMode.backwards
        self.likeButton.layer.add(animation, forKey: nil)
    }
    
    
}
