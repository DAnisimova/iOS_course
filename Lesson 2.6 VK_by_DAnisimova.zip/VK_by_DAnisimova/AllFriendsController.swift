//
//  AllFriendsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsController: UITableViewController, UISearchResultsUpdating {
    
    
    var friends: [Friend] = [
        Friend(name: "Elon Musk", image: UIImage(named: "ElonMusk")!, imageSet: [UIImage(named: "ElonMusk1")!, UIImage(named: "ElonMusk2")!, UIImage(named: "ElonMusk3")!]),
        Friend(name: "Jennifer Lopez", image: UIImage(named: "JLo")!, imageSet: [UIImage(named: "JLo1")!, UIImage(named: "JLo2")!, UIImage(named: "JLo3")!]),
        Friend(name: "Eminem", image: UIImage(named: "Eminem")!, imageSet: [UIImage(named: "Eminem")!, UIImage(named: "Eminem1")!]),
        Friend(name: "Megan Fox", image: UIImage(named: "MeganFox")!, imageSet: [UIImage(named: "MeganFox")!, UIImage(named: "MeganFox1")!]),
        Friend(name: "Usain Bolt", image: UIImage(named: "UsainBolt")!, imageSet: [UIImage(named: "UsainBolt")!, UIImage(named: "UsainBolt1")!]),
        Friend(name: "Walle", image: UIImage(named: "Walle")!, imageSet: [UIImage(named: "Walle1")!, UIImage(named: "Walle2")!, UIImage(named: "Walle3")!])
    ]
    
// Переменные для создания секций
    var sections: [String: [Friend]] = [:] // массив из ключей и соответсвующих контактов
    var keys: [String] = [] // ключи для секций (в нашем случае первые буквы)
    
// Переменные для создания строки поиска
    var searchResults: [Friend] = [] // пустой элемент структуры, куда будут попадать элементы поиска
    let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
// Функция для разделения списка на секции по первым буквам имени
        friends.forEach { friend in
            let firstLetter = String(friend.name.first!)
            if sections[firstLetter] != nil {
                sections[firstLetter]!.append(friend)
            } else {
                sections[firstLetter] = [friend]
            }
        }
        keys = Array(sections.keys).sorted(by: <)
        
// Манипуляции для создания строки поиска
        searchController.searchResultsUpdater = self
        self.definesPresentationContext = true
        
        self.tableView.tableHeaderView = searchController.searchBar // поместили строку поиска в хедер
        self.tableView.contentOffset = CGPoint(x: 0, y: searchController.searchBar.frame.height) // чтобы скрыть строку поиска при первом появлянии списка друзей
    }
    
        func filterContent(for searchText: String) {
            searchResults = friends.filter({ (Friend) -> Bool in // обновляем массив на основе результатов совпадений
                let match = title?.range(of: searchText, options: .caseInsensitive)
                return match != nil // возвращаем совпадение
                })
        }
    
    
// Для соответсвия протоколу UISearchResultsUpdating
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text { // если строка поиска содердит текст, отфильтруй по строке
            filterContent(for: searchText)
            tableView.reloadData() // перезагрузи таблицу с результатами поиска
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? { // добавили буквы сбоку
        return keys
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return keys[section] // добавили буквы вверху секции
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        header.tintColor = UIColor.clear // сделали цвет хедера бесцветным
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = keys[section]
        let count = sections[key]!.count
        return searchController.isActive ? searchResults.count : count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! AllFriendsCell
        
        let key = keys[indexPath.section] // узнаем какая буква сейчас в секции
        
        let friend = searchController.isActive ? searchResults[indexPath.row] : sections[key]![indexPath.row] // извлекаем друга из этой секции
        
        cell.friendName.text = friend.name
        cell.friendImage.image = friend.image
        
        return cell
    }
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "showPhotos" {
               guard let destinationVC = segue.destination as? FriendViewController else {return}
               if let indexPath = tableView.indexPathForSelectedRow {
                   let user = friends[indexPath.row]
                   destinationVC.images.append(contentsOf: user.imageSet)
               }
           }
      }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
   
}

