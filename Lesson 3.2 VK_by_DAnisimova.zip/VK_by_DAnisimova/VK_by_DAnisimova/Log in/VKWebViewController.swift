//
//  VKWebViewController.swift
//  VK_by_DAnisimova
//
//  Created by User on 30/01/2021.
//  Copyright © 2021 User. All rights reserved.
//

import UIKit
import WebKit

class VKWebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView! {
        didSet {
            webView.navigationDelegate = self
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    
    var urlComponents = URLComponents()
            urlComponents.scheme = "https"
            urlComponents.host = "oauth.vk.com"
            urlComponents.path = "/authorize"
            urlComponents.queryItems = [
                URLQueryItem(name: "client_id", value: "7745512"), // идентификатор приложения
                URLQueryItem(name: "display", value: "mobile"), // тип отображения
                URLQueryItem(name: "redirect_uri", value: "https://oauth.vk.com/blank.html"), // адрес куда будет переадресован пользователь после прохождения авторизации
                URLQueryItem(name: "scope", value: "262150"), // битовая маска пользователя
                URLQueryItem(name: "response_type", value: "token"), // тип ответа который надо получить
                URLQueryItem(name: "v", value: "5.68")
    ]
        
    let request = URLRequest(url: urlComponents.url!)
    
    webView.load(request)
        
        NetworkManager.networkManager.getMyFriendsList()
        NetworkManager.networkManager.getPhotosOfSelectedFriend()
        NetworkManager.networkManager.getMyGroups()
        NetworkManager.networkManager.getMyGroupsWithSearch()
        
    }
}

extension VKWebViewController: WKNavigationDelegate {
    
    private func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        guard let url = navigationResponse.response.url,
              url.path == "/blank.html",
              let fragment = url.fragment
        else {
            decisionHandler(.allow)
            return
        }
        
        let params = fragment
            .components(separatedBy: "&")
            .map { $0.components(separatedBy: "=")}
            .reduce([String: String]()) { result, param in
                var dict = result
                let key = param[0]
                let value = param[1]
                dict[key] = value
                return dict
            }
        
        let token = params["access_token"]
        let userID = params["user_id"]
        
        Session.instance.token = token!
        Session.instance.userID = Int(userID!)!
        
        
        print(Session.instance.token)
        print(Session.instance.userID)
        
        
        performSegue(withIdentifier: "VKLoginSegue", sender: nil)
        
        decisionHandler(.cancel)
    }
}

