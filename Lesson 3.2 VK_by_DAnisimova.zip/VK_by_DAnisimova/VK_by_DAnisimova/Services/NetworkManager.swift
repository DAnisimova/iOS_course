//
//  NetworkManager.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 15.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire

class NetworkManager {
    
    static var networkManager = NetworkManager()
    
    private init() {}
    
    let baseUrl = "https://api.vk.com/method/"
    
    func getMyFriendsList() {
        let path = "/friends.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "v": 5.52
        ]
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseJSON { response in
            print(response.value!)
        }
    }
    
    func getPhotosOfSelectedFriend() {
        let path = "/photos.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "owner_id": 66265,
            "album_id": "profile",
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseJSON { response in
            print(response.value!)
        }
    }
    
    func getMyGroups() {
        let path = "/groups.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "extended": 1,
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseJSON { response in
            print(response.value!)
        }
    }
    
    func getMyGroupsWithSearch() {
        let path = "/groups.search"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "q": "All about Swift",
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseJSON { response in
            print(response.value!)
        }
    }
}

