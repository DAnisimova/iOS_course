//
//  Session.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 13.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire


struct Session {
    
    static var instance = Session() // синглтон для хранения данных
    
    private init() {}
    
    // свойства
    var token: String = "a1e65904aad3b77d20d37d0b86d0186348a82d329f8f1df51aec7c6f65f8a5fd0c4a073058fecd23a6296"
    var userID: Int = 0
    
}
