//
//  ViewController.swift
//  VK_by_DAnisimova
//
//  Created by User on 18/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let likeButton = LikeButton()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.addSubview(self.likeButton)
        self.likeButton.translatesAutoresizingMaskIntoConstraints = false
        
        let constraintY = self.likeButton.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        let constraintX = self.likeButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        constraintX.isActive = true
        constraintY.isActive = true
        
        let width = self.likeButton.widthAnchor.constraint(equalToConstant: 50)
        let height = self.likeButton.heightAnchor.constraint(equalToConstant: 50)
        width.isActive = true
        height.isActive = true
        
        self.likeButton.addTarget(self, action: #selector(handleHeartTap), for: .touchUpInside)
        
    }
    
     @objc
        func handleHeartTap() {
        if self.likeButton.likeState == .like {
            self.likeButton.likeState = .liked
        } else {
            self.likeButton.likeState = .like
            
        }
        }
        
    
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
