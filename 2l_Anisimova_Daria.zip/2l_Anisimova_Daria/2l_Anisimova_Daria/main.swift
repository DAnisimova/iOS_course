//
//  main.swift
//  2l_Anisimova_Daria
//
//  Created by user179829 on 9/26/20.
//

import Foundation

print("Hello, World!")

//Task 2.1

func evenNumber(_ number: Int) {
    if number % 2 == 0{
        print("It's even")
    } else {
        print("It's odd")
    }
}

print(evenNumber(5))

//Task 2.2

func divideByThree(_ number: Int) {
    if number % 3 == 0 {
        print("You can divide by three")
    } else {
        print("You can't divede by three")
    }
}

print(divideByThree(99))

//Task 2.3

var array: [Int] = []

for i in 1 ... 100 {
    array.append(i)
}
print(array)

//Task 2.4

for value in array {
    if (value % 2) == 0 {
        array.remove(at: array.firstIndex(of: value)!)
    }
}

print(array)

for value in array {
    if (value % 3) == 0 {
        array.remove(at: array.firstIndex(of: value)!)
    }
}

print(array)
