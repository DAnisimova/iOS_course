import Cocoa

var str = "Hello, playground"

struct Car {
    let year: Int
    var price: Int
    var count: Int
    let brand: Brand
}

struct Brand {
    let brand: String
}

enum CarSaleError: Error {
    case invalidBrand
    case invalidYear
    case outOfStock
    case notEnoughBudget(neededBudget: Int)
    
    var errorDescription: String {
        switch self {
        case .invalidBrand:
            return "Бренда нет в ассортименте"
        case .invalidYear:
            return "Вы ввели неправильный год"
        case .outOfStock:
            return "Нет в наличии"
        case .notEnoughBudget(neededBudget: let neededBudget):
            return "Превышает бюджет, необходимо еще: \(neededBudget)"
        }
    }
}

class Warehouse {
    
    var carForSale = [
        "BMW": Car(year: 2020, price: 5000000, count: 0, brand: Brand(brand: "BMW")),
        "Mercedes": Car(year: 2019, price: 2000000, count: 3, brand: Brand(brand: "Mercedes")),
        "Porsche": Car(year: 2018, price: 9000000, count: 1, brand: Brand(brand: "Porsche")),
    ]
    
    var budget = 5000000
    
    func sell(carNamed brand: String) -> (car: Brand?, error: CarSaleError?) {
        
        guard let car = carForSale[brand] else { return (car: nil, error: CarSaleError.invalidBrand) }
        
        guard car.count > 0 else { return (car: nil, error: CarSaleError.outOfStock) }
        
        guard car.year <= 2020 else { return (car: nil, error: CarSaleError.invalidYear) }
        
        guard car.price <= budget else { return (car: nil, error: CarSaleError.notEnoughBudget(neededBudget: car.price - budget))
        }
        
        budget -= car.price
        
        var newCar = car
        newCar.count -= 1
        carForSale[brand] = newCar
        return (car: newCar.brand, error: nil)
    }
}

/*
let warehouse = Warehouse()
    
let sale1 = warehouse.sell(carNamed: "Audi")
let sale2 = warehouse.sell(carNamed: "BMW")
warehouse.budget = 8000000
let sale3 = warehouse.sell(carNamed: "Porsche")
let sale4 = warehouse.sell(carNamed: "Mercedes")
    
for sale in [sale1, sale2, sale3, sale4] {
    if let brand = sale.car {
        print("Вы купили: \(brand.brand)")
    } else if let error = sale.error {
        print("Произошла ошибка: \(error.errorDescription)")
    }
}
*/

extension Warehouse {
    
    func rightSell(carNamed brand: String) throws -> Brand {
        
        guard let car = carForSale[brand] else {
            throw CarSaleError.invalidBrand }
        
        guard car.count > 0 else {
            throw CarSaleError.outOfStock }
        
        guard car.year <= 2020 else {
            throw CarSaleError.invalidYear }
        
        guard car.price <= budget else {
            throw CarSaleError.notEnoughBudget(neededBudget: car.price - budget)
        }
        
        budget -= car.price
        
        var newCar = car
        newCar.count -= 1
        carForSale[brand] = newCar
        return newCar.brand
    }
}

let warehouse = Warehouse()

do {

let someSale = try warehouse.rightSell(carNamed: "Audi")
    print("Вы купили: \(someSale.brand)")
    
//} catch let error as CarSaleError {
//    print(error.localizedDescription)
} catch CarSaleError.invalidBrand {
    print("Бренда нет в ассортименте")
} catch CarSaleError.invalidYear {
    print("Вы ввели неправильный год")
} catch CarSaleError.outOfStock {
    print("Нет в наличии")
} catch let CarSaleError.notEnoughBudget(neededBudget: neededBudget) {
    print("Превышает бюджет, необходимо еще: \(neededBudget)")
} catch {
    print("Что-то сломалось")
}

