//
//  main.swift
//  7l_Anisimova_Daria
//
//  Created by user179829 on 10/14/20.
//

import Foundation

print("Hello, World!")

