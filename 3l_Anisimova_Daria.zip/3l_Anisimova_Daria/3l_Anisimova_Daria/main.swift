//
//  main.swift
//  3l_Anisimova_Daria
//
//  Created by user179829 on 9/30/20.
//

import Foundation

print("Hello, World!")

enum CarBrand {
    case BMW, Porshe, Mercedes, Scania, Volvo
}

enum CarMotorState {
    case on, off
}

enum CarWindowState {
    case open, close
}

enum CarFuel {
    case petrol, diesel
}

struct SportCar {
    let brand: CarBrand
    let year: Int
    var freeTrunk: Double {
        didSet {
            let fullTrunk = oldValue - freeTrunk
            print("Объем заполненного багажника: \(fullTrunk) литров")
        }
    }
    var motorState: CarMotorState
    var windowState: CarWindowState
    var fuel: CarFuel
}

var sportCar1 = SportCar(brand: CarBrand.BMW, year: 2020, freeTrunk: 35.0, motorState: .on, windowState: .open, fuel: .diesel)

sportCar1.freeTrunk = 25

print(sportCar1)

func printSportCarProperties (sportCar: SportCar) {
    print("------------------------------------------------------------------------")
    print("Бренд: \(sportCar.brand)")
    print("Год выпуска: \( sportCar.year)")
    print("Объем багажника: \( sportCar.freeTrunk)")
    print("Мотор: \( sportCar.motorState == .on ? "Включен" : "Выключен")")
    print("Окна: \( sportCar.windowState == .open ? "Открыты" : "Закрыты")")
    print("Топливо: \( sportCar.fuel == .petrol ? "Бензин" : "Дизель")")
}

printSportCarProperties(sportCar: sportCar1)

var sportCar2 = SportCar(brand: .Mercedes, year: 2019, freeTrunk: 25, motorState: .off, windowState: .open, fuel: .petrol)

printSportCarProperties(sportCar: sportCar2)

sportCar2.windowState = .close

printSportCarProperties(sportCar: sportCar2)


enum CarTonnage {
    case small, middle, big
}

struct TrunkCar {
    let brand: String
    let year: Int
    var freeTrunk: Double {
        didSet {
            let fullTrunk = oldValue - freeTrunk
            print("Объем заполненного багажника: \(fullTrunk) литров")
        }
    }
    var motorState: CarMotorState
    var windowState: CarWindowState
        willSet(newValue) {
            if newValue == .open {
            print("Окна будут открыты")
            } else {
            print("Окна будут закрыты")
               }
    var fuel: CarFuel
    var tonnage: CarTonnage

    mutating func startTheEngine () {
        self.motorState = .on
}
    mutating func shutDownTheEngine () {
        self.motorState = .off
        }
    }
}
    

trunk.startTheEngine()
trunk.motorState
