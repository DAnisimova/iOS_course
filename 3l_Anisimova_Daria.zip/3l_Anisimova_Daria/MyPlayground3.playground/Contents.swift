import Cocoa

var str = "Hello, playground"

enum CarBrand {
    case BMW, Porshe, Mercedes, Scania, Volvo
}

enum CarMotorState {
    case on, off
}

enum CarWindowState {
    case open, close
}

enum CarFuel {
    case petrol, diesel
}

struct SportCar {
    let brand: CarBrand
    let year: Int
    var freeTrunk: Double {
        didSet {
            let fullTrunk = oldValue - freeTrunk
            print("Объем заполненного багажника: \(fullTrunk) литров")
        }
    }
    var fuel: CarFuel
    var motorState: CarMotorState
    var windowState: CarWindowState {
        willSet {
        if newValue == .open {
        print("Окна будут открыты")
        } else {
        print("Окна будут закрыты")
           }
    }
}
}

var sportCar1 = SportCar(brand: CarBrand.BMW, year: 2020, freeTrunk: 35.0, fuel: .diesel, motorState: .on, windowState: .open)

sportCar1.freeTrunk = 25

func printSportCarProperties (sportCar: SportCar) {
    print("------------------------------------------------------------------------")
    print("Бренд: \(sportCar.brand)")
    print("Год выпуска: \( sportCar.year)")
    print("Объем багажника: \( sportCar.freeTrunk)")
    print("Мотор: \( sportCar.motorState == .on ? "Включен" : "Выключен")")
    print("Окна: \( sportCar.windowState == .open ? "Открыты" : "Закрыты")")
    print("Топливо: \( sportCar.fuel == .petrol ? "Бензин" : "Дизель")")
}

printSportCarProperties(sportCar: sportCar1)

var sportCar2 = SportCar(brand: .Mercedes, year: 2019, freeTrunk: 25, fuel: .petrol, motorState: .off, windowState: .open)

printSportCarProperties(sportCar: sportCar2)

sportCar2.windowState = .close

printSportCarProperties(sportCar: sportCar2)


enum CarTonnage {
    case small, middle, big
}

struct TrunkCar {
    let brand: CarBrand
    let year: Int
    var freeTrunk: Double {
        didSet {
            let fullTrunk = oldValue - freeTrunk
            print("Объем заполненного багажника: \(fullTrunk) литров")
        }
    }
    var fuel: CarFuel
    var tonnage: CarTonnage
    var motorState: CarMotorState
    var windowState: CarWindowState {
        willSet {
        if newValue == .open {
        print("Окна будут открыты")
        } else {
        print("Окна будут закрыты")
        }
        }
    }
    mutating func shutDownTheEngine() {
        self.motorState = .off
        }
    mutating func startTheEngine() {
        self.motorState = .on
        }
    
}

var trunk = TrunkCar(brand: .Scania, year: 2015, freeTrunk: 600, fuel: .diesel, tonnage: .big, motorState: .off, windowState: .close)

func printTrunkCarProperties (trunkCar: TrunkCar) {
    print("------------------------------------------------")
    print("Бренд: \(trunkCar.brand)")
    print("Год выпуска: \( trunkCar.year)")
    print("Объем багажника: \( trunkCar.freeTrunk)")
    print("Топливо: \( trunkCar.fuel == .petrol ? "Бензин" : "Дизель")")
    print("Грузоподъемность: \( trunkCar.tonnage)")
    print("Мотор: \( trunkCar.motorState == .on ? "Включен" : "Выключен")")
    print("Окна: \( trunkCar.windowState == .open ? "Открыты" : "Закрыты")")
}

printTrunkCarProperties(trunkCar: trunk)

trunk.startTheEngine()
trunk.motorState

struct CarWithInit {
    let year: Int
    let brand: String
    
    init() {
        year = 2020
        brand = "Porshe"
    }
    
    init (year: Int, brand: String){
        self.year = year
        self.brand = brand
    }
}

let car1 = CarWithInit()
