//
//  User.swift
//  VK_by_DAnisimova
//
//  Created by User on 15/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import Foundation
import UIKit

struct Friend {
    let name: String
    let image: UIImage
    let imageSet: [UIImage]
}
