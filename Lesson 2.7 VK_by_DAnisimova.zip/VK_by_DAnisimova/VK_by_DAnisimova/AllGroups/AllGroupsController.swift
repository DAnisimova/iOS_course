//
//  AllGroupsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllGroupsController: UITableViewController, UISearchBarDelegate {
    
    let allGroups: [Group] = [
        Group(name: "All about Swift", logo: UIImage(named: "Swift")!),
        Group(name: "BMW fans", logo: UIImage(named: "BMW")!),
        Group(name: "FC Zenith", logo: UIImage(named: "Zenit")!)
    ]
    
    var filteredGroups: [Group]!
    

    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
        
        filteredGroups = allGroups
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredGroups.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GroupCell", for: indexPath) as! AllGroupsCell
        
        let group = filteredGroups[indexPath.row]
        
        cell.groupName.text = group.name
        cell.groupImage.image = group.logo
        
        return cell
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredGroups = []
        
        if searchText == "" {
            filteredGroups = allGroups
        } else {
        
            for group in allGroups {
            
                if group.name.lowercased().contains(searchText.lowercased()) {
                    
                filteredGroups.append(group)
            }
            }
        }
        self.tableView.reloadData()
    }
}


