//
//  LoadingViewController.swift
//  VK_by_DAnisimova
//
//  Created by User on 07/01/2021.
//  Copyright © 2021 User. All rights reserved.
//

import UIKit

class LoadingViewController: UIViewController {

    @IBOutlet weak var view1: UIView! {didSet{
        self.view1.layer.cornerRadius = self.view1.frame.width/2.0
        self.view1.clipsToBounds = true
        }
    }
    
    @IBOutlet weak var view2: UIView! {didSet{
        self.view2.layer.cornerRadius = self.view2.frame.width/2.0
        self.view2.clipsToBounds = true
        }
    }

    @IBOutlet weak var view3: UIView! {didSet{
        self.view3.layer.cornerRadius = self.view3.frame.width/2.0
        self.view3.clipsToBounds = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1.5, delay: 0,
                       animations: {
                        self.view1.backgroundColor = UIColor.systemBlue
        })
        UIView.animate(withDuration: 1.5, delay: 1,
                       animations: {
                        self.view2.backgroundColor = UIColor.systemBlue
        })
        UIView.animate(withDuration: 1.5, delay: 2,
                       animations: {
                        self.view3.backgroundColor = UIColor.systemBlue
        },
        completion: { (success) in
            self.performSegue(withIdentifier: "Next", sender: self)
        })
    }
}

