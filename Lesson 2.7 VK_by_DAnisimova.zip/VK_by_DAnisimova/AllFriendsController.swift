//
//  AllFriendsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsController: UITableViewController, UISearchBarDelegate {
    
    
    @IBOutlet weak var friendsSearchBar: UISearchBar!
    
    let friends: [Friend] = [
        Friend(name: "Elon Musk", image: UIImage(named: "ElonMusk")!, imageSet: [UIImage(named: "ElonMusk1")!, UIImage(named: "ElonMusk2")!, UIImage(named: "ElonMusk3")!]),
        Friend(name: "Jennifer Lopez", image: UIImage(named: "JLo")!, imageSet: [UIImage(named: "JLo1")!, UIImage(named: "JLo2")!, UIImage(named: "JLo3")!]),
        Friend(name: "Eminem", image: UIImage(named: "Eminem")!, imageSet: [UIImage(named: "Eminem")!, UIImage(named: "Eminem1")!]),
        Friend(name: "Megan Fox", image: UIImage(named: "MeganFox")!, imageSet: [UIImage(named: "MeganFox")!, UIImage(named: "MeganFox1")!]),
        Friend(name: "Usain Bolt", image: UIImage(named: "UsainBolt")!, imageSet: [UIImage(named: "UsainBolt")!, UIImage(named: "UsainBolt1")!]),
        Friend(name: "Walle", image: UIImage(named: "Walle")!, imageSet: [UIImage(named: "Walle1")!, UIImage(named: "Walle2")!, UIImage(named: "Walle3")!])
    ]
    
    var filteredFriends: [Friend]!
    
// Переменные для создания секций
    var sections: [String: [Friend]] = [:] // массив из ключей и соответсвующих контактов
    var keys: [String] = [] // ключи для секций (в нашем случае первые буквы)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        friendsSearchBar.delegate = self
        filteredFriends = friends
    
// Функция для разделения списка на секции по первым буквам имени
        friends.forEach { friend in
            let firstLetter = String(friend.name.first!)
            if sections[firstLetter] != nil {
                sections[firstLetter]!.append(friend)
            } else {
                sections[firstLetter] = [friend]
            }
        }
        keys = Array(sections.keys).sorted(by: <)

    }
    
    
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? { // добавили буквы сбоку
        return keys
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return keys[section] // добавили буквы вверху секции
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        header.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = keys[section]
        let count = sections[key]!.count
        return count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! AllFriendsCell
        
        let key = keys[indexPath.section] // узнаем какая буква сейчас в секции
        
        let friend = sections[key]![indexPath.row]
        
        cell.friendName.text = friend.name
        cell.friendImage.image = friend.image
        
        UIView.animate(
            withDuration: 1,
            delay: 0,
            usingSpringWithDamping: 0.4,
            initialSpringVelocity: 0.8,
            options: .curveEaseInOut,
            animations: {
                cell.frame.origin.x+=70
        })
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.alpha = 0
        UIView.animate(
            withDuration: 0.8,
            animations: {
                cell.alpha = 1
        })
    }
    
// Отображение галереи с фото при нажатии на ячейку с другом
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "showPhotos" { // проверка на нужный переход
               guard let destinationVC = segue.destination as? FriendViewController else {return} // проверка перехода на нужный контроллер
            if let indexPath = tableView.indexPathForSelectedRow { // 
                   let user = friends[indexPath.row]
                   destinationVC.images.append(contentsOf: user.imageSet)
               }
           }
      }

//Функция для фильтра по введенному в строку поиска тексту
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredFriends = []
        
        if searchText == "" {
            filteredFriends = friends
        }
        else {
            for friend in friends {
                if friend.name.lowercased().contains(searchText.lowercased()) {
                    filteredFriends.append(friend)
                }
            }
        }
        self.tableView.reloadData()
    }
}

