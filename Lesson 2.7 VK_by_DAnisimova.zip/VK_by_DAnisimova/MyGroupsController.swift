//
//  AllGroupsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class MyGroupsController: UITableViewController {
    
    
    var myGroups: [Group] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myGroups.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyGroupCell", for: indexPath) as! MyGroupsCell
        
        let myGroup = myGroups[indexPath.row]
        
        cell.groupName.text = myGroup.name
        cell.groupImage.image = myGroup.logo
        
        return cell
    }
  
    @IBAction func addGroup(segue: UIStoryboardSegue) {
        
        if segue.identifier == "addGroup" { // проверяем нужный индикатор
            let allGroupsController = segue.source as! AllGroupsController// получаем ссылку на контроллер, с которого осуществлен переход
            
            if let indexPath = allGroupsController.tableView.indexPathForSelectedRow { // получаем индекс выделенной ячейки
                
                let group = allGroupsController.allGroups[indexPath.row] // получаем группу по индексу
//                if !myGroups.contains(group) { // ОШИБКА - Argument type 'Group' does not conform to expected type 'Equatable'
                myGroups.append(group) // добавляем в список Мои группы
                
                tableView.reloadData() // обновляем таблицу
            }
        }
    }
//    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            myGroups.remove(at: indexPath.row) // удаляем группу из массива
            tableView.deleteRows(at: [indexPath], with: .fade) // удаляем строку из таблицы
        }
    }
    
}

