//
//  FriendsLoader.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 25.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire

struct VKFriendsListResponse: Codable {
    let response: VKFriendsResponse
}

struct VKFriendsResponse: Codable {
    let count: Int
    let items: [VKFriends]
}

struct VKFriends: Codable {
    let first_name: String
    let id: Int
    let last_name: String
    let photo_200: String
}

class FriendsLoader {
    
    let baseUrl = "https://api.vk.com/method/"
    
    func getMyFriendsList(complitionHandler: @escaping ([VKFriends]) -> Void) {
        let path = "/friends.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "v": 5.52,
            "fields": "photo_200"
        ]
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            do {
                let friend = try! JSONDecoder().decode(VKFriendsListResponse.self, from: response.value!)
                complitionHandler(friend.response.items)
                print(friend)
            } catch {
                print(error)
            }
        }
    }
}
