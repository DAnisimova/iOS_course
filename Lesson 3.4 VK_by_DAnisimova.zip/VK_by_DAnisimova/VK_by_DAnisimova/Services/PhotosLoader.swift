//
//  PhotosLoader.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 25.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire

struct VKPhotosListResponse: Codable {
    let response: VKPhotosResponse
}

struct VKPhotosResponse: Codable {
    let count: Int
    let items: [VKPhotos]
}

struct VKPhotos: Codable {
    let id: Int
    let album_id: Int
    let owner_id: Int
    let sizes: [Sizes]
}

struct Sizes: Codable {
    let src: String
    let width: Int
    let height: Int
    let type: String
}

class PhotosLoader {
    
    let baseUrl = "https://api.vk.com/method/"
    
    func getPhotosOfSelectedFriend(ownerId: Int, handler: @escaping ([VKPhotos]) -> Void) {
        let path = "/photos.getAll"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "owner_id": ownerId,
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            do {
                let photo = try! JSONDecoder().decode(VKPhotosListResponse.self, from: response.value!)
                handler(photo.response.items)
                print(photo)
            } catch {
                print(error)
            }

        }
    }
}
