//
//  NetworkManager.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 15.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire


class NetworkManager {
    
    static var networkManager = NetworkManager()
    
    private init() {}
    
    func getImage(by urlStr: String, handler: @escaping ((Data) -> Void)) {
        guard let url = URL(string: urlStr) else { return }
        
        if let data = try? Data(contentsOf: url) {
            handler(data)
        }
    }
}


