//
//  Session.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 13.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire


class Session {
    
    static let instance = Session() // синглтон для хранения данных
    
    // свойства
    var token: String = "8bdcd1789b728f47863b7a9f00c9ef06546890bc9d5cb54922011c592e843f8a384dc64a9c08a81955167"
    var userId: Int = 0
    
    private init() {}
    
}

