//
//  GroupLoader.swift
//  VK_by_DAnisimova
//
//  Created by Darya on 25.02.2021.
//  Copyright © 2021 User. All rights reserved.
//

import Foundation
import Alamofire

struct VKGroupsListResponse: Codable {
    let response: VKGroupsResponse
}

struct VKGroupsResponse: Codable {
    let count: Int
    let items: [VKGroups]
}

struct VKGroups: Codable, Equatable {
    let id: Int
    let name: String
    let photo_200: String
    let type: String
    
    static func == (lhs: VKGroups, rhs: VKGroups) -> Bool {
        return lhs.name == rhs.name && lhs.photo_200 == rhs.photo_200
    }
}

class GroupsLoader {
    
    let baseUrl = "https://api.vk.com/method/"
    
    func getMyGroups(complitionHandler: @escaping ([VKGroups]) -> Void) {
        let path = "/groups.get"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "extended": 1,
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            do {
                let group = try! JSONDecoder().decode(VKGroupsListResponse.self, from: response.value!)
                complitionHandler(group.response.items)
                print(group)
            } catch {
                print(error)
            }
           
        }
    }
    
    func getAllGroups(complitionHandler: @escaping ([VKGroups]) -> Void) {
        let path = "/groups.getCatalog"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "extended": 1,
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            do {
                let group = try! JSONDecoder().decode(VKGroupsListResponse.self, from: response.value!)
                complitionHandler(group.response.items)
                print(group)
            } catch {
                print(error)
            }
           
        }
    }
    
    func getMyGroupsWithSearch(searchText: String, complitionHandler: @escaping ([VKGroups]) -> Void) {
        let path = "/groups.search"
        let parameters: Parameters = [
            "access_token": Session.instance.token,
            "q": searchText.lowercased(),
            "v": 5.52
        ]
        
        let url = baseUrl + path
        
        Alamofire.request(url, method: .get, parameters: parameters).responseData { response in
            do {
                let groupWithSearch = try! JSONDecoder().decode(VKGroupsListResponse.self, from: response.value!)
                complitionHandler(groupWithSearch.response.items)
                print(groupWithSearch)
            } catch {
                print(error)
            }
            
        }
    }
}
