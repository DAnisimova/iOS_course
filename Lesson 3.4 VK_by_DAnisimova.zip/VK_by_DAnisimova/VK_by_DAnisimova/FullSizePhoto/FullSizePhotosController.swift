//
//  FullSizePhotosController.swift
//  VK_by_DAnisimova
//
//  Created by User on 09/01/2021.
//  Copyright © 2021 User. All rights reserved.
//

import UIKit


class FullSizePhotosController: UIViewController {

    @IBOutlet weak var photoImageView1: UIImageView!
    var bigPhoto: UIImage!
    var allPhotos: [UIImage]!
    
    var interactiveAnimator = UIViewPropertyAnimator()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        photoImageView1.isUserInteractionEnabled = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.photoImageView1.image = bigPhoto // для отображения фото в большом формате каждый раз раз при нажатии по галерее
    }
    
}
