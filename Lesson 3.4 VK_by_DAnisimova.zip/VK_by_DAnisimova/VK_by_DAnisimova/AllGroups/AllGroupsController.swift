//
//  AllGroupsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 13/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllGroupsController: UITableViewController, UISearchBarDelegate {
    
    let session = Session.instance
    let data = GroupsLoader()
    var allGroups = [VKGroups]()
    
    var filteredGroups: [VKGroups]!
    

    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        data.getAllGroups() { [weak self] group in
            self?.allGroups = group
            self?.tableView.reloadData()
        }
        
        searchBar.delegate = self
        
        filteredGroups = allGroups
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredGroups.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GroupCell", for: indexPath) as! AllGroupsCell
        
        let group = filteredGroups[indexPath.row]
        
        cell.groupName.text = group.name
        
        NetworkManager.networkManager.getImage(by: group.photo_200) { (data) in
            let image = UIImage(data: data)
            cell.groupImage.image = image
            
        }
        
        return cell
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredGroups = []
        if searchText == "" {
            filteredGroups = allGroups
        } else {
            for group in allGroups {
                if group.name.lowercased().contains(searchText.lowercased()) {
                filteredGroups.append(group)
            }
            }
        }
        self.tableView.reloadData()
    }
}


