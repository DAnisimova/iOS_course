//
//  AllFriendsController.swift
//  VK_by_DAnisimova
//
//  Created by User on 12/12/2020.
//  Copyright © 2020 User. All rights reserved.
//

import UIKit

class AllFriendsController: UITableViewController, UISearchBarDelegate {
    
    @IBOutlet weak var friendsSearchBar: UISearchBar!
    
    let session = Session.instance
    let data = FriendsLoader()
    var myFriends = [VKFriends]()
    
    var photos: [Sizes] = []
    
    
// Переменные для создания секций
    var sections: [String: [VKFriends]] = [:] // массив из ключей и соответсвующих контактов
    var keys: [String] = [] // ключи для секций (в нашем случае первые буквы)
    var filteredFriends: [String: [VKFriends]] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        data.getMyFriendsList() { [weak self] friend in
            self?.myFriends = friend
            self?.tableView.reloadData()
        }
        
        friendsSearchBar.delegate = self
        filteredFriends = sections
    
// Функция для разделения списка на секции по первым буквам имени
        myFriends.forEach { friend in
            let firstLetter = String(friend.first_name.first!)
            if sections[firstLetter] != nil {
                sections[firstLetter]!.append(friend)
            } else {
                sections[firstLetter] = [friend]
            }
        }
        keys = Array(sections.keys).sorted(by: <)

    }
    
    
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? { // добавили буквы сбоку
        return keys
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return keys[section] // добавили буквы вверху секции
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        header.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = keys[section]
        let count = sections[key]!.count
        return count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! AllFriendsCell
        
        let key = keys[indexPath.section] // узнаем какая буква сейчас в секции
        
        let friend = sections[key]![indexPath.row] // берем друга из соответствующей секции
        
        cell.friendName.text = friend.first_name + " " + friend.last_name
        
        NetworkManager.networkManager.getImage(by: friend.photo_200) { (data) in
            let image = UIImage(data: data)
            cell.friendImage.image = image
            
        }
        
        UIView.animate(
            withDuration: 1,
            delay: 0,
            usingSpringWithDamping: 0.4,
            initialSpringVelocity: 0.8,
            options: .curveEaseInOut,
            animations: {
                cell.frame.origin.x+=70
        })
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.alpha = 0
        UIView.animate(
            withDuration: 0.8,
            animations: {
                cell.alpha = 1
        })
    }
    
// Отображение галереи с фото при нажатии на ячейку с другом

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "showPhotos" { // проверка на нужный переход
               guard let destinationVC = segue.destination as? FriendViewController else {return} // проверка перехода на нужный контроллер
            if let indexPath = tableView.indexPathForSelectedRow {
                let key = keys[indexPath.section]
                let user = sections[key]![indexPath.row]
//                destinationVC.ownerID = user.id
//                destinationVC.images.append(contentsOf: user.imageSet)
               }
           }
      }

    
//Функция для фильтра по введенному в строку поиска тексту
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredFriends = [:]
        
        if searchText == "" {
            filteredFriends = sections
        }
        else {
            for friend in myFriends {
                if friend.first_name.lowercased().contains(searchText.lowercased()) {
//                    filteredFriends.append(friend)
                }
            }
        }
        self.tableView.reloadData()
    }
    
}
