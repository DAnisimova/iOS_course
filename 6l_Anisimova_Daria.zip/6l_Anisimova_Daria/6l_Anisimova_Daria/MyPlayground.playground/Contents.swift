import Cocoa

var str = "Hello, playground"
 
protocol SalaryProtocol {
    var salary: Double { get set }
}

class Man: SalaryProtocol {
    var euroInRub: Double
    var sumEuroToBuy: Double
    var salary: Double
    
    func calculateSumEuro() -> Double {
        return euroInRub * sumEuroToBuy
    }
    
    init(euroInRub: Double, sumEuroToBuy: Double, salary: Double) {
        self.euroInRub = euroInRub
        self.sumEuroToBuy = sumEuroToBuy
        self.salary = salary
    }
}

class Woman: SalaryProtocol {
    var dollarInRub: Double
    var sumDollarToBuy: Double
    var salary: Double
    
    func calculateSumDollar() -> Double {
        return dollarInRub * sumDollarToBuy
    }
    
    init(dollarInRub: Double, sumDollarToBuy: Double, salary: Double) {
        self.dollarInRub = dollarInRub
        self.sumDollarToBuy = sumDollarToBuy
        self.salary = salary
    }
}

struct Queue<T: SalaryProtocol> {
    private var elements: [T] = []
    
    mutating func push(_ element: T){
        elements.append(element)
    }
    mutating func pop() -> T? {
        guard elements.count > 0 else { return nil}
        return elements.removeFirst()
    }
}


enum People: SalaryProtocol {
    case man(Man)
    case woman(Woman)
    
    var salary: Double {
        get {
            switch self {
            case .man(let man):
                return man.salary
            case .woman(let woman):
                return woman.salary
            }
        }
        set {
            switch self {
            case .man(let man):
                man.salary = newValue
            case.woman(let woman):
                woman.salary = newValue
            }
        }
    }
}

var queuePeople = Queue<People>()

queuePeople.push(.man(Man(euroInRub: 89, sumEuroToBuy: 680, salary: 2550000)))
queuePeople.push(.man(Man(euroInRub: 90, sumEuroToBuy: 700, salary: 1870000)))
queuePeople.push(.woman(Woman(dollarInRub: 81, sumDollarToBuy: 300, salary: 450000)))
queuePeople.push(.woman(Woman(dollarInRub: 82, sumDollarToBuy: 550, salary: 98000)))
queuePeople.push(.man(Man(euroInRub: 91, sumEuroToBuy: 100, salary: 25000)))

var person1 = queuePeople.pop()
var person2 = queuePeople.pop()
var person3 = queuePeople.pop()
var person4 = queuePeople.pop()


var arraySalary: [Double] = []

arraySalary.append(person1!.salary)
arraySalary.append(person2!.salary)
arraySalary.append(person3!.salary)
arraySalary.append(person4!.salary)


arraySalary.sort { $0 < $1 }
print(arraySalary)

arraySalary.sort { $0 > $1 }
print(arraySalary)

let sal1 = arraySalary.map { $0 + 1.0 }
print(sal1)

extension Queue {
    
    subscript(index: Int) -> Double? {
        
        guard index >= 0 && index < self.elements.count else {return nil}
        return self.elements[index].salary
}
}

queuePeople[0]
queuePeople[3]
