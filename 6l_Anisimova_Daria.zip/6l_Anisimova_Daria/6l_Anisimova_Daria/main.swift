//
//  main.swift
//  6l_Anisimova_Daria
//
//  Created by user179829 on 10/13/20.
//

import Foundation

print("Hello, World!")

